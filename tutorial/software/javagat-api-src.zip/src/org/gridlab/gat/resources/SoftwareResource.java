/*
 * Created on Apr 22, 2004
 */
package org.gridlab.gat.resources;

/**
 * @author rob
 */
/**
 * An abstract representation of a piece of software. A piece of software might
 * be a library, plugin or other piece of software.
 */
public abstract class SoftwareResource implements Resource {
    /* No extra methods */
}
