package masterkey.workflow;

import org.gridlab.gat.GAT;
import org.gridlab.gat.GATObjectCreationException;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.Job.JobState;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.SoftwareDescription;

/**
 * A class representing an execution slot on a certain resource. 
 * 
 * @author jason
 */
class Slot {
    
    // The broker used to access the resource.
    private final ResourceBroker broker; 
    
    // The current job running on the resource.
    private Job job;
    
    // The current task running in the job.
    private Task task;
    
    // The current jobID. 
    private int jobID; 
    
    /** 
     * Constructor the create an execution slot for a certain resource. 
     *
     * @param broker the broker needed to access this resource.
     */
    public Slot(ResourceBroker broker) {
        this.broker = broker;         
    }
    
    /** 
     * Set the current jobID and task.
     * 
     * @param jobID the jobID of the current job.
     * @param task the task that should be executed.
     */
    public void configure(int jobID, Task task) { 
        this.jobID = jobID;
        this.task = task;
    }

    /** 
     * Clears the execution slot.
     */
    public void clear() { 
        task = null;
        job = null;
    }
     
    /** 
     * Submit the current task to the resource.
     * 
     * @param stageID the name of the current stage (used to generate output files).
     * 
     * @throws Exception is the submission failed.
     */
    public void submit(String stageID) throws Exception {
        job = broker.submitJob(prepareJob(stageID));
    }
    
    /**
     * Check if the task is done. 
     * 
     * @return if the task is done.
     */
    public boolean isDone() {
        return (job == null || job.getState() == JobState.STOPPED || job.getState() == JobState.SUBMISSION_ERROR);
    }      
        
    /**
     * Creates a JobDescription for running the current task on the resource this slot represents. 
     *
     * @param stageID the name of the workflow stage this job belongs to (used to generate output files).
     * @return a JobDescription for starting a Job on the resource
     * @throws GATObjectCreationException if the JobDescription could not be created. 
     */
    private JobDescription prepareJob(String stageID) throws GATObjectCreationException {
        SoftwareDescription sd = new SoftwareDescription();

        sd.setExecutable("/bin/sh");
        sd.setStdout(GAT.createFile(stageID + "-stdout-" + jobID + ".txt"));
        sd.setStderr(GAT.createFile(stageID + "-stderr-" + jobID + ".txt"));
        sd.setArguments(new String [] { task.script, task.input, task.output });
        
        return new JobDescription(sd);
    }    
}