package masterkey.basic;

import org.gridlab.gat.GAT;
import org.gridlab.gat.URI;

/** Rename using the JavaGAT */
public class Rename {

    /**
     * Renames a file.
     * 
     * @param args
     *            the arguments. args[0] should contain the original name, args[1] the
     *            new name
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: SOURCE DESTINATION");
            System.exit(0);
        }
        
        GAT.createFile(args[0]).renameTo(GAT.createFile(new URI(args[1])));
        GAT.end();
    }
}
