package masterkey.basic;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import org.gridlab.gat.GAT;
import org.gridlab.gat.GATContext;
import org.gridlab.gat.URI;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.Job.JobState;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.SoftwareDescription;
import org.gridlab.gat.security.CertificateSecurityContext;

/** 
 * Example of job submission to globus which requires a password.
 * 
 * No in or output staging is performed, so the executable to 
 * start should be available on the target resource. 
 */
public class RunJobWithCertificate {

    // Ask the user for the password needed to perform grid-proxy-init
    private static String getPassphrase() {
        JPasswordField pwd = new JPasswordField();

        Object[] message = { "grid-proxy-init\nPlease enter your passphrase.",
                pwd };
        
        JOptionPane.showMessageDialog(null, message, "Grid-Proxy-Init",
                JOptionPane.QUESTION_MESSAGE);
        return new String(pwd.getPassword());
    }
    
    /**
     * Start a job on a (possibly remote) resource using globus. Ask the user 
     * for a password to perform a grid-proxy-init. 
     * 
     * @param args the arguments. 
     *              args[0] should contains the resource URI, 
     *              args[1] the path to the executable to start on that resource.
     * 
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: MACHINE EXECUTABLE");
            System.exit(0);
        }

        // Create a new CertificateSecurityContext containing the globus certificates 
        // and the user password.   
        CertificateSecurityContext securityContext = new CertificateSecurityContext(
                new URI(System.getProperty("user.home") + "/.globus/userkey.pem"), 
                new URI(System.getProperty("user.home") + "/.globus/usercert.pem"), 
                getPassphrase());

        // Store this SecurityContext in a GATContext
        GATContext context = new GATContext();
        context.addSecurityContext(securityContext);

        // Use the GATContext when creating a resource broker. This way, the JavaGAT
        // adaptor for globus can find the information it needs when submitting jobs.
        ResourceBroker broker = GAT.createResourceBroker(context, new URI(args[0]));

        // Create a software description containing the executable name, and 
        // two files for any output that is generated on stdout or stderr.
        SoftwareDescription sd = new SoftwareDescription();
        sd.setExecutable(args[1]);
        sd.setStdout(GAT.createFile("stdout.txt"));
        sd.setStderr(GAT.createFile("stderr.txt"));

        // Submit the job and poll until it terminates.
        Job job = broker.submitJob(new JobDescription(sd));

        do {
            System.out.println("Current state: " + job.getState());
            Thread.sleep(100);
        } while ((job.getState() != JobState.STOPPED)
                && (job.getState() != JobState.SUBMISSION_ERROR));

        GAT.end();
    }
}
