package masterkey.workflow;


import java.util.LinkedList;

import masterkey.util.Filter;

import org.gridlab.gat.GAT;
import org.gridlab.gat.URI;
import org.gridlab.gat.io.File;
import org.gridlab.gat.resources.ResourceBroker;


/**
 * This class represents a stage in a workflow.
 * 
 * 
 * 
 * @author jason
 */
class Stage {
    
    // The name of the current stage.
    private String stageID;
    
    // The broker URI of where the task should run.
    private String brokerURI;
    
    // The maximum number of execution slots allowed on this broker.
    private int maxJobs;
    
    // The script to run in this stage.
    private String script;    
    
    // The input file or directory.
    private String input;
    
    // The extension of the input files in the input directory (optional). 
    private String inputExt;
    
    // The output file or directory.
    public final String output;
    
    // The available execution slots (not running a task). 
    private LinkedList<Slot> emptySlots = new LinkedList<Slot>();
    
    // The active execution slots (running a task). 
    private LinkedList<Slot> runningSlots = new LinkedList<Slot>();
    
    // The task to run.
    private LinkedList<Task> tasks = new LinkedList<Task>();
            
    // A Job counter (used when a job is submitted by JavaGAT).
    private int jobID = 1;
    
    /** 
     * Constructor that parses a String containing a workflow stage description.
     * 
     * @param line the workflow stage description. 
     * @throws Exception if the line could not be parsed.
     */
    public Stage(String line) throws Exception { 
        String [] tmp = line.split(",");
        
        if (tmp.length != 7) { 
            throw new Exception("Failed to parse workflow stage (" + tmp.length + ") " + line);
        }
        
        this.stageID = tmp[0].trim();
        this.brokerURI = tmp[1].trim();;
        this.maxJobs = Integer.parseInt(tmp[2].trim());
        this.script = tmp[3].trim();
        this.input = tmp[4].trim();  
        this.inputExt = tmp[5].trim().equals("-") ? null : tmp[5].trim();
        this.output = tmp[6].trim();
    }
    
    /**
     * Start the next task in the given execution slot.
     * 
     * @param slot the execution slot to start the task in.
     * @throws Exception if the task submission failed.
     */
    public void submit(Slot slot) throws Exception {         
        Task task = tasks.removeFirst();
        slot.configure(jobID++, task);
        slot.submit(stageID);
        runningSlots.addLast(slot);                   
    }
    
    /**
     * Initialize this stage.
     * 
     * Creates a ResourceBroker to access the resource, creates the required 
     * number of execution slots, and fills the task list.  
     * 
     * @throws Exception if the initialization failed.
     */
    public void initialize() throws Exception { 
            
        System.out.println("Initializing stage [" + stageID + "]");
        
        System.out.println("Creating resource broker for " + brokerURI);
        
        ResourceBroker broker = GAT.createResourceBroker(new URI(brokerURI));
            
        System.out.println("Creating " + maxJobs + " deployment slots");
        
        // Create the execution slots.
        for (int i=0;i<maxJobs;i++) { 
            emptySlots.add(new Slot(broker));
        }               
        
        // Find the input files.
        String [] inputFiles = null;
        
        if (inputExt == null) {
            inputFiles = new String [] { input };
        } else { 
            // We need to expand the input directory (which is remote).
            String location = "ssh://" + new URI(brokerURI).getHost() + File.separator + input;
            
            File file = GAT.createFile(location);
            
            if (file.exists() && file.canRead() && file.isDirectory()) { 
                inputFiles = file.list(new Filter(inputExt));                
            } else { 
                throw new Exception("Cannot access input directory: " + input);
            }
            
            for (int i=0;i<inputFiles.length;i++) { 
                inputFiles[i] = file.getPath() + File.separator + inputFiles[i];
            }
        }
        
        // Create one task for each input file.
        for (String in : inputFiles) { 
            tasks.addLast(new Task(script, in, output));
        }

        System.out.println("Created " + tasks.size() + " tasks");
    } 
    
    /**
     * Executes this stage of the workflow by executing all tasks
     * on the available execution slots.
     * 
     * @throws Exception the execution has failed.
     */
    public void run() throws Exception { 
            
        System.out.println("Running stage [" + stageID + "]");
        
        int totalTasks = tasks.size();
        
        // Keep processing until we run out of tasks.
        while (!(runningSlots.size() == 0 && tasks.size() == 0)) { 
            
            System.out.println("Tasks " + tasks.size() + " waiting / " + 
                    runningSlots.size() + " running / " +
                    (totalTasks-tasks.size()-runningSlots.size()) + " done");
            
            // Submit a task to each empty slot.
            while (emptySlots.size() > 0 && tasks.size() > 0) {
                submit(emptySlots.removeFirst());
            }
        
            // We have now run out of slots or tasks and poll the 
            // currently running slots to see if anyone is done.
            int running = runningSlots.size();
            
            for (int i=0;i<running;i++) { 
                Slot slot = runningSlots.removeFirst();
                
                if (slot.isDone()) {
                    emptySlots.addLast(slot);
                } else { 
                    runningSlots.addLast(slot);
                }
            }
            
            // If the poll did not produce an empty slot
            // we sleep for a while.
            if (emptySlots.size() == 0) { 
                try { 
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // ignored
                }
            }
        }
    }
}
