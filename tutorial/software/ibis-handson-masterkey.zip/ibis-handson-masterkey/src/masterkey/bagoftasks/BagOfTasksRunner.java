package masterkey.bagoftasks;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import masterkey.util.ProcessRunner;
import masterkey.util.ProcessRunnerCallBack;


/** 
 * A simple bag-of-tasks application. 
 * 
 * When this application is run on a resource, it read a bag of 
 * tasks from disk and dynamically distributes these tasks over 
 * the available cores.
 * 
 * @author jason
 *
 */
public class BagOfTasksRunner implements ProcessRunnerCallBack {
   
    /** 
     * Helper class to sort Tasks according to size.
     */
    static class TaskComparator implements Comparator<Task> {
        @Override
        public int compare(Task t1, Task t2) {
            return (int)(t2.size - t1.size);
        } 
    }
    
    // The tasks that need to be run.
    private LinkedList<Task> tasks = new LinkedList<Task>();     
    
    // The processrunner used to run the tasks.
    private ProcessRunner [] runners;
    
    // The number of pending tasks.
    private int pending;

    // The total processing time for each of the tasks.
    private long processingTime;
    
    // The start time of this ag-of-task runner and the deadline
    // at which it should stop running.
    private long startTime, deadline; 
    
    // A flag indicating if we have reached the deadline.
    private boolean done = false;
  
    // A write that writes the descriptions of the finished tasks.
    private BufferedWriter output;
    
    /** 
     * Constructor for the bag-of-tasks runner.
     * 
     * @param inputFile the file describing the bag of tasks.
     * @param timeLimit the timelimit for this runner (in minutes).
     * @param outputFile the outputfile to which the finished tasks should be written.
     * @throws Exception if the runner failed to initialize.
     */
    public BagOfTasksRunner(String inputFile, String timeLimit, String outputFile) throws Exception { 

        // Compute the deadline
        int minutes = Integer.parseInt(timeLimit);
        
        startTime = System.currentTimeMillis();         
        deadline = startTime + (minutes * 60 * 1000); 
        
        System.out.println("Deadline set to " + minutes + " minutes.");
        
        // Create the outputfile 
        output = new BufferedWriter(new FileWriter(outputFile));
        
        System.out.println("Created output file " + outputFile);
        
        // Read the configuration file
        readInputFile(inputFile);

        pending = tasks.size();
        
        System.out.println("Bag contains " + pending + " tasks.");
        
        // Detect the number of cores on this machine
        int cores = Runtime.getRuntime().availableProcessors();
        
        System.out.println("Machine contains " + cores + " cores.");
        
        runners = new ProcessRunner[cores];
    }

    // Parses the input file containing the description of the tasks in the bag
    private void readInputFile(String inputFile) throws Exception { 
        
        BufferedReader reader = new BufferedReader(new FileReader(inputFile)); 
        
        String line = reader.readLine();
        
        while (line != null) { 
            tasks.add(Task.read(line));
            line = reader.readLine();
        }
        
        reader.close();
        
        Collections.sort(tasks, new TaskComparator());
    }
    
    // Start a task in processrunner slot [index].
    private synchronized void startTask(int index) { 
        if (tasks.size() > 0) {
            Task t = tasks.removeFirst();
            
            System.out.println("Starting task " + t.ID);
            
            runners[index] = new ProcessRunner(index, t, t.getCommand(), "taskout-" + t.ID, "taskerr-" + t.ID, this);            
            runners[index].start();
        }
    }
    
    @Override
    public synchronized void processTerminated(int index, Object info, int status, long time, String message) {

        // Clean up the mess
        runners[index] = null;
        
        // If we have passed the deadline we ignore this call 
        if (done) { 
            return;
        }
        
        // Retrieve the task and extract its processingtime
        Task task = (Task) info;

        processingTime += time;
        
        // Write the task to the completed tasks file.
        try { 
            output.write(task.ID + "," + status + "," + message + "\n");
            output.flush();
        } catch (Exception e) {
            System.err.println("Failed to write ");
        }
        
        System.out.println("Finished task " + task.ID);
        
        pending--;

        if (pending <= 0) { 
            // If there are no more tasks we signal the runner that we are done.
            notifyAll();
        } else { 
            // Start a new task in our slot.
            startTask(index); 
        }
    }

    // Waits until we run out of tasks or pass the deadline
    private synchronized void waitUntilDeadline() { 
        
        while (pending > 0 && System.currentTimeMillis() < deadline) { 
            try { 
                wait(1000);
            } catch (Exception e) {
                // ignored
            }            
        }

        // Set the "we are done" flag.
        done = true;
        
        // Close the output file.
        try { 
            output.close();
        } catch (Exception e) {
            // ignored
        }
        
        // Kill any remaining jobs.
        if (pending <= 0) { 
            System.out.println("Terminating -- no more jobs!");
        } else { 
            System.out.println("Terminating -- no more time!");
            
            for (int i=0;i<runners.length;i++) { 
                if (runners[i] != null) { 
                    runners[i].kill();
                }
            }
        }
        
        // Calculate our efficiency.
        long deltaTime = System.currentTimeMillis() - startTime;
        
        System.out.println("Efficiency: " + ((100.0 * processingTime) / (runners.length * deltaTime))); 
    }
    
    // Run as many tasks as possible until the deadline is reached.
    private void run() { 
        
        synchronized (this) { 
            for (int i=0;i<runners.length;i++) {
                startTask(i);
            }
        }
        
        waitUntilDeadline();
    }
    
    /**
     * Main method for the bag-of-tasks runner.
     * 
     * @param args command line arguments.
     */
    public static void main(String [] args) {
        
        // Expects [inputfile timelimit outputfile]
        System.out.println("Starting BagOfTasksRunner(" + Arrays.toString(args) + ")");
        
        try {
            new BagOfTasksRunner(args[0], args[1], args[2]).run();
        } catch (Exception e) {
            System.err.println(" BagOfTasksRunner failed: " + e);
            e.printStackTrace(System.err);
        }
    }
}
