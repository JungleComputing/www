package masterkey.bagoftasks;

/**
 * This object represents a Task. 
 * 
 * @author jason
 */
class Task {

    /** The task ID */
    public final long ID; 

    /** The task size (optional) */
    public final long size; 

    /** The script to run */
    public final String script;

    /** The name of the input file */
    public final String inputFile;

    /** The name of the output file */
    public final String outputFile;

    /**
     * Constructor to create a task. 
     * 
     * @param ID a unique task ID.
     * @param size the size of the task (0 if unused)
     * @param script the script to execute.
     * @param input the input file or directory
     * @param output the output file or directory.
     */
    public Task(long ID, long size, String script, String input, String output) {
        this.ID = ID;        
        this.size = size;
        this.script = script;
        this.inputFile = input;
        this.outputFile = output;
    } 
    
    /** 
     * Generate a command array that can be executed by a ProcessRunner.
     * 
     * @return the command array for this task.
     */
    public String [] getCommand() { 
        return new String[] { "/bin/sh", script, inputFile, outputFile };
    }
    
    /** 
     * Converts a Task into a String representation.
     * 
     * @param t the task to convert.
     * @return the String representation of the given task.
     */
    public static String write(Task t) { 
        return t.ID + " " + t.size + " " + t.script + " " + t.inputFile + " " + t.outputFile;
    }
    
    /**
     * Converts a String representation of a Task back into a Task.
     * 
     * @param line the String to convert.
     * @return the Task generated using the input line. 
     * @throws Exception if the line could not be converted.
     */
    public static Task read(String line) throws Exception { 
        String [] tmp = line.split(" ");
        
        if (tmp.length != 5) { 
            throw new Exception("Failed to parse task: " + line);
        }
            
        return new Task(Long.parseLong(tmp[0]), Long.parseLong(tmp[1]), tmp[2], tmp[3], tmp[4]);
    }
}