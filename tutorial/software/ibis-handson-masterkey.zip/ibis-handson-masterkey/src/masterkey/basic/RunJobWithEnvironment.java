package masterkey.basic;

import java.util.HashMap;
import java.util.Map;

import org.gridlab.gat.GAT;
import org.gridlab.gat.GATContext;
import org.gridlab.gat.URI;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.SoftwareDescription;
import org.gridlab.gat.resources.Job.JobState;

/** 
 * Simple job submission example using the JavaGAT. 
 * 
 * No in or output staging is performed, so the executable to 
 * start should be available on the target resource. 
 */
public class RunJobWithEnvironment {

    /**
     * Start a job on a (possibly remote) resource.
     * 
     * @param args the arguments. 
     *              args[0] should contains the resource URI, 
     *              args[1] the path to the executable to start on that resource.
     * 
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: MACHINE EXECUTABLE");
            System.exit(0);
        }
        
        ResourceBroker broker = GAT.createResourceBroker(new URI(args[0]));

        // Create a software description containing the executable name, and 
        // two files for any output that is generated on stdout or stderr.
        SoftwareDescription sd = new SoftwareDescription();
        sd.setExecutable(args[1]);
        sd.setStdout(GAT.createFile("stdout.txt"));
        sd.setStderr(GAT.createFile("stderr.txt"));
        
        Map<String, Object> environment = new HashMap<String, Object>();
        environment.put("SOME_SETTING", "some-value");
        sd.setEnvironment(environment);
        
        // Submit the job and poll until it terminates.
        Job job = broker.submitJob(new JobDescription(sd));

        do {
            System.out.println("Current state: " + job.getState());
            Thread.sleep(1000);
        } while ((job.getState() != JobState.STOPPED)
                && (job.getState() != JobState.SUBMISSION_ERROR));

        GAT.end();
    }
}
