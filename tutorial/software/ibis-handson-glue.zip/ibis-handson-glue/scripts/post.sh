#!/bin/sh

# creates a directory and unpack a file of images
tar cvfz $2 $1

