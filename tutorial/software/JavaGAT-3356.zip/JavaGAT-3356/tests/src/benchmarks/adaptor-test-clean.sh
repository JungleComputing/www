#!/bin/bash

sleep 2

rm -rf /tmp/JavaGAT-test-exists-file
rm -rf /tmp/JavaGAT-test-exists-dir
rm -rf ~/JavaGAT-test-exists-file
rm -rf ~/JavaGAT-test-exists-dir

rm -rf /tmp/JavaGAT-test-mkdir-dir
rm -rf ~/JavaGAT-test-mkdir-dir

rm -rf ~/JavaGAT-test-filedir-file
rm -rf ~/JavaGAT-test-filedir-dir

rm -rf ~/JavaGAT-test-mode-*

rm -rf ~/JavaGAT-test-length

rm -rf ~/JavaGAT-test-list

rm -rf ~/JavaGAT-test-last-modified

rm -rf ~/JavaGAT-test-new-file

rm -rf ~/JavaGAT-test-mkdirs
rm -rf /tmp/JavaGAT-test-mkdirs

rm -rf ~/JavaGAT-test-copy-large
rm -rf ~/JavaGAT-test-copy-small

rm -rf /tmp/JavaGAT-test-copy-large
rm -rf /tmp/JavaGAT-test-copy-small
