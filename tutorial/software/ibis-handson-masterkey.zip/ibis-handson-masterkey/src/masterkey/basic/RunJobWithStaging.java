package masterkey.basic;

import java.util.Arrays;

import org.gridlab.gat.GAT;
import org.gridlab.gat.URI;
import org.gridlab.gat.io.File;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.SoftwareDescription;
import org.gridlab.gat.resources.Job.JobState;

/**
 * Job submission example for jobs with arguments and in and output files.
 * 
 * In this example, the command line of the executable to run is expected to
 * have the format:
 * 
 * /path/to/executable inputfile [arguments] outputfile
 * 
 * Note that only the input and output files are copied to and from the target
 * resource. The executable is assumed to be already available there.
 */
public class RunJobWithStaging {

    /**
     * Start a job on a (possibly remote) resource, including file staging 
     * and command line arguments. 
     * 
     * @param args the arguments. 
     *              args[0] should contains the resource URI, 
     *              args[1] the path to the executable to start on that resource.
     *              args[2] should contain the URI of the input file
     *              args[3*] should contain the executable's command line arguments 
     *              args[n-1] should contain the outputfile URI
     * 
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: MACHINE EXECUTABLE INPUT [ARGUMENTS*] OUTPUT");
            System.exit(0);
        }

        // Create a resource broker using the resource URI in args[0].
        ResourceBroker broker = GAT.createResourceBroker(new URI(args[0]));

        // Create a software description containing the executable name 
        // (in args[1]), and create two files for any output that is generated 
        // on stdout or stderr.
        SoftwareDescription sd = new SoftwareDescription();
        sd.setExecutable(args[1]);
        sd.setStdout(GAT.createFile("stdout.txt"));
        sd.setStderr(GAT.createFile("stderr.txt"));

        // Use args[2] and args[n-1] as the input and output file names
        File input = GAT.createFile(args[2]);
        File output = GAT.createFile(args[args.length - 1]);

        // Set the input and output file to be prestaged and poststaged.
        sd.addPreStagedFile(input);
        sd.addPostStagedFile(output);

        // The rest of the arguments are command line arguments for the 
        // executable
        String[] arguments = Arrays.copyOfRange(args, 2, args.length);

        // Also add the input and output file names to the arguments for the 
        // executable, taking care to remove any path. 
        arguments[0] = input.getName();
        arguments[arguments.length - 1] = output.getName();

        // Set the command line arguments for the executable and submit the job.
        sd.setArguments(arguments);
        Job job = broker.submitJob(new JobDescription(sd));

        // Poll until the job terminates.
        do {
            System.out.println("Current state: " + job.getState());
            Thread.sleep(1000);
        } while ((job.getState() != JobState.STOPPED)
                && (job.getState() != JobState.SUBMISSION_ERROR));

        GAT.end();
    }
}
