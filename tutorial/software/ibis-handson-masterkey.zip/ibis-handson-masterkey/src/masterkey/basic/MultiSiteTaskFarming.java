package masterkey.basic;

import java.io.FilenameFilter;
import java.util.Arrays;

import org.gridlab.gat.GAT;
import org.gridlab.gat.GATObjectCreationException;
import org.gridlab.gat.URI;
import org.gridlab.gat.io.File;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.SoftwareDescription;
import org.gridlab.gat.resources.Job.JobState;

public class MultiSiteTaskFarming {

    public static class Filter implements FilenameFilter {

        final String ext;

        Filter(String ext) {
            this.ext = ext;
        }

        @Override
        public boolean accept(java.io.File dir, String name) {
            return name.endsWith(ext);
        }
    }

    public static String[] listInputs(String input, String ext)
            throws GATObjectCreationException {

        java.io.File inputdir = new java.io.File(input);

        if (!inputdir.isDirectory()) {
            System.err.println("Need directory as input!");
            System.exit(1);
        }

        return inputdir.list(new Filter(ext));
    }

    public static String[] prepareArguments(String input, String[] arguments,
            String output) {

        String[] tmp = new String[arguments.length + 2];

        tmp[0] = input;
        System.arraycopy(arguments, 0, tmp, 1, arguments.length);
        tmp[tmp.length - 1] = output;

        return tmp;
    }

    public static JobDescription prepareJob(int number, String executable,
            String[] arguments, File input, File output)
            throws GATObjectCreationException {

        SoftwareDescription sd = new SoftwareDescription();

        sd.setExecutable(executable);

        sd.setStdout(GAT.createFile("stdout-" + number + ".txt"));
        sd.setStderr(GAT.createFile("stderr-" + number + ".txt"));

        sd.addPreStagedFile(input);

        // CAVEAT: The single parameter call specifies the -source- of the file
        // we are staging out.
        // By default these files will be staged back to the current local
        // directory. Therefore, we
        // need to specify a target location is we want to store the output file
        // in the "output"
        // directory.
        sd.addPostStagedFile(GAT.createFile(output.getName()), output);

        // Set the arguments and submit the job.
        sd.setArguments(prepareArguments(input.getName(), arguments,
                output.getName()));

        return new JobDescription(sd);
    }

    public static void waitUntilFinished(Job[] jobs) throws InterruptedException {
        System.err.print("Waiting for jobs: ");
        
        for (Job job : jobs) {
            while ((job.getState() != JobState.STOPPED)
                    && (job.getState() != JobState.SUBMISSION_ERROR)) {
                Thread.sleep(500);
            }
            System.err.print(".");
        }
        System.err.println();
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: MACHINE[,MACHINE, ...] EXECUTABLE INPUT_DIR [ARGUMENTS ...] OUTPUT_DIR");
            System.exit(0);
        }

        //get list of brokers
        String[] brokerURIs = args[0].split(",");
        
        ResourceBroker[] brokers = new ResourceBroker[brokerURIs.length];
        for(int i = 0; i < brokers.length; i++) {
            brokers[i] = GAT.createResourceBroker(new URI(brokerURIs[i]));
        }

        String executable = args[1];

        String inputdir = args[2];
        String[] arguments = Arrays.copyOfRange(args, 3, args.length - 1);
        String outputdir = args[args.length - 1];

        String[] inputs = listInputs(inputdir, ".jpg");

        Job[] jobs = new Job[inputs.length];

        System.err.print("Submitting jobs:  ");
        for (int i = 0; i < inputs.length; i++) {
            File input = GAT.createFile(inputdir + File.separator + inputs[i]);
            File output = GAT.createFile(outputdir + File.separator + "out-"
                    + input.getName());
            
            //round robin
            ResourceBroker broker = brokers[i % brokers.length];
            
            jobs[i] = broker.submitJob(prepareJob(i, executable, arguments,
                    input, output));
            System.err.print(".");
        }
        System.err.println();

        waitUntilFinished(jobs);

        GAT.end();
    }
}
