package masterkey.bagoftasks;

/** 
 * This class serves as a container for all information on a resource.
 * 
 * @author jason
 */
public class Resource {
    
    /** The URI of the ResourceBroker. */
    public final String brokerURI;
   
    /** The location of java on the resource. */
    public final String javaLocation;
    
    /** The maximum number of execution slots to use. */
    public final int maxJobs;
   
    /** The time limit for running a single bag. */
    public final int timeLimit; 
   
    /** The maximum number of tasks in each bag. */
    public final int bagSize;

    /**
     * Constructor for a Resouce.
     * 
     * @param brokerURI the URI of the ResourceBroker.
     * @param javaLocation the location of Java on the resource.
     * @param maxJobs the maximum number of execution slots to use.
     * @param timeLimit the time limit for running a single bag.
     * @param bagSize the maximum tasks to put in a bag.
     */
    public Resource(String brokerURI, String javaLocation, int maxJobs, int timeLimit, int bagSize) {
        this.brokerURI = brokerURI;
        this.javaLocation = javaLocation;
        this.maxJobs = maxJobs;
        this.timeLimit = timeLimit;
        this.bagSize = bagSize;
    }

}