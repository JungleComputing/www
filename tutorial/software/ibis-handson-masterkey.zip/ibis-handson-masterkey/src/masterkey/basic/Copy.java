package masterkey.basic;

import org.gridlab.gat.GAT;
import org.gridlab.gat.URI;

/** Simple FileCopy example using the JavaGAT */
public class Copy {

    /**
     * Copies a file between two (possibly remote) locations..
     * 
     * @param args
     *            the arguments. args[0] should contain the source, args[1] the
     *            destination
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("USAGE: SOURCE DESTINATION");
            System.exit(0);
        }
        
        GAT.createFile(args[0]).copy(new URI(args[1]));
        GAT.end();
    }
}
