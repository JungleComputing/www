#!/bin/bash

rm -rf ~/JavaGAT-test-fileoutputstream