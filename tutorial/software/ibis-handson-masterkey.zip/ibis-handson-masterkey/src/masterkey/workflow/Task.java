package masterkey.workflow;

/**
 * This object represents a task that needs to be performed. 
 * 
 * @author jason
 */
class Task {

    /** The script to run */
    public final String script;

    /** The name of the input file or directory */
    public final String input;

    /** The name of the output file or directory */
    public final String output;

    /**
     * Constructor to create a task.
     * 
     * @param script path to the script to execute.  
     * @param input the input location (file or directory).
     * @param output the output location (file or directory).
     */
    public Task(String script, String input, String output) {
        this.script = script;
        this.input = input;
        this.output = output;
    } 
    
    /** 
     * Creates a command array that can be executed by a ProcessRunner.
     * 
     * @return the command array.
     */
    public String [] getCommand() { 
        return new String[] { "/bin/sh", script, input, output };
    }    
}