package masterkey.workflow;


import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

import masterkey.util.FileUtils;


/** 
 * Example of a simple workflow engine using JavaGAT.
 * 
 * @author jason
 */
public class Main {
    
    // The stages of the workflow
    private LinkedList<Stage> workflow = new LinkedList<Stage>();
    
    /** 
     * Constructor of Workflow engine. 
     * 
     * @param file a file containing a description of the workflow to execute.
     * 
     * @throws Exception if workflow description could not be read.
     */
    public Main(String file) throws Exception {        
        
        BufferedReader reader = new BufferedReader(new FileReader(file));
        
        String line = reader.readLine();
        
        while (line != null) {
            
            line = line.trim();
            
            if (line.length() > 0 && !line.startsWith("#")) { 
                workflow.addLast(new Stage(line));
            }
            
            line = reader.readLine();
        }
    }
    
    /** 
     * Execute each stage of the workflow.
     * 
     * @throws Exception a stage failed.
     */
    public void run() throws Exception {     
        for (Stage stage : workflow) {
            stage.initialize();
            stage.run();
        }
    } 
    
    /** 
     * Main method to start workflow engine from the command line.
     *  
     * @param args command line arguments.
     */
    public static void main(String[] args) {

        if (args.length != 1) { 
            System.out.println("Usage: tutorial20.workflow.Main [workflow file]");
        }
        
        try {
            FileUtils.ensureFileExists(args[0]); 
            new Main(args[0]).run();
        } catch (Exception e) {
            System.err.println("Failed to run workflow: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}
