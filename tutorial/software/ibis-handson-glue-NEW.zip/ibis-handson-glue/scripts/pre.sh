#!/bin/sh

# creates a directory and unpack a file of images
mkdir -p $2
cd $2
tar xvfz $1

