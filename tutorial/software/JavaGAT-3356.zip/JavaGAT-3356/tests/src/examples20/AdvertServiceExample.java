package examples20;

public class AdvertServiceExample {

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("See examples20.EndpointExample");
    }

}
