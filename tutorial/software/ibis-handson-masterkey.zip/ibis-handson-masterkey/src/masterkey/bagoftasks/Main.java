package masterkey.bagoftasks;


import java.io.File;
import java.util.LinkedList;

import masterkey.util.FileUtils;

import org.gridlab.gat.GAT;
import org.gridlab.gat.URI;
import org.gridlab.gat.resources.ResourceBroker;


/**
 * Main class for a bag-of-tasks executor.
 * 
 * @author jason
 */
public class Main {
    
    // The unused execution slots on the resources.
    private LinkedList<Slot> emptySlots = new LinkedList<Slot>();
    
    // The active execution slots on the resources.
    private LinkedList<Slot> runningSlots = new LinkedList<Slot>();

    // The tasks to process.
    private LinkedList<Task> tasks = new LinkedList<Task>();
        
    // The finished tasks.
    private LinkedList<Task> done = new LinkedList<Task>();
    
    /** A Job counter used to identify JavaGAT jobs. */
    int jobID = 1;

    /** A task counter used to identify tasks. */
    long taskID = 1;
    
    /** 
     * Constructor for the bag-of-tasks executor.
     * 
     * @param resources the resources to use.
     * @param script the script to execute.
     * @param inputDir the local input directory.
     * @param outputDir the local output directory.
     * @throws Exception if the bag-of-tasks executor failed to initialize.
     */
    public Main(LinkedList<Resource> resources, String script, 
            String inputDir, String outputDir) throws Exception {
        
        // List the input files 
        String scriptName = new File(script).getName();
        
        String [] files = FileUtils.listFiles(inputDir, ".jpg");
        
        // Create a task for each input file
        for (String file : files) {
            tasks.add(new Task(taskID++, 
                    new File(inputDir + File.separator + file).length(), 
                    scriptName, file, "out-" + file));
        }

        if (tasks.size() == 0) { 
            throw new Exception("No tasks found in " + inputDir);
        }
        
        System.out.println("Created " + tasks.size() + " tasks.");
        
        // Create resource brokers for each of the resources.
        for (Resource resource : resources) {            
            System.out.println("Creating resource broker for " + 
                    resource.brokerURI + " (" + resource.maxJobs + " slots)");
            
            ResourceBroker broker = GAT.createResourceBroker(new URI(resource.brokerURI));
            
            for (int i=0;i<resource.maxJobs;i++) { 
                emptySlots.add(new Slot(resource, broker, script, inputDir, outputDir));
            }
        }               
    } 
    
    // Submit a bag-of-tasks to an empty execution slot.
    private void submit(Slot slot) { 
        
        // First create a bag and fill it.
        LinkedList<Task> bag = new LinkedList<Task>();
        
        for (int i=0;i<slot.resource.bagSize && tasks.size() > 0; i++) {
            bag.add(tasks.removeFirst());
        } 
        
        // Next, give it to an execution slot and submit to the resource.
        try { 
            slot.configure(jobID++, bag);
            slot.submit();
            runningSlots.addLast(slot);                   
        } catch (Exception e) {
            System.out.println("ERROR: Failed to submit to " + slot.resource.brokerURI + ": " + e);
            e.printStackTrace();

            // Return tasks and slot.
            tasks.addAll(bag);
            emptySlots.addLast(slot);
        }        
    }

    // Cleanup an finished execution slot.
    private void cleanup(Slot slot) { 
        
        // Extract the finished and unfinished tasks.
        LinkedList<Task> todo = new LinkedList<Task>();
        
        slot.retrieveTasks(done, todo);
        
        if (todo.size() > 0) {
            System.out.println("Resubmitting " + todo.size() + " tasks.");
            tasks.addAll(todo);
        }
        
        // Return the execution slot to the empty list.
        emptySlots.addLast(slot);
    }
    
    // Run all tasks.
    private void run() throws Exception { 
        
        int totalTasks = tasks.size();
        
        // Keep going while we have tasks or running processes.
        while (!(runningSlots.size() == 0 && tasks.size() == 0)) { 
            
            // First, we submit as many bags as we can
            System.out.println("Tasks " + 
                    tasks.size() + " waiting / " +
                    (totalTasks - tasks.size() - done.size()) + " pending / " +
                    done.size() + " done"); 
            
            while (emptySlots.size() > 0 && tasks.size() > 0) {
                submit(emptySlots.removeFirst());
            }
        
            // We have now run out of slots or tasks. In either case we 
            // poll the currently running slots to see if anyone is done.
            int running = runningSlots.size();
            
            for (int i=0;i<running;i++) { 
                Slot slot = runningSlots.removeFirst();
                
                if (slot.isDone()) { 
                    cleanup(slot);
                } else { 
                    runningSlots.addLast(slot);
                }
            }
            
            // If the poll was unsuccessful we sleep for a while.
            if (emptySlots.size() == 0) { 
                try { 
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // ignored
                }
            }
        }

        GAT.end();
        
        System.out.println("Done!");
    }
    
    /** 
     * Main method for bag-of-tasks runner. 
     * 
     * @param args command line arguments.
     */
    public static void main(String[] args) {

        LinkedList<Resource> resources = new LinkedList<Resource>();

        String script = null;
        String inputDir = null;
        String outputDir = null;

        try {
        
            for (int i = 0; i < args.length; i++) {
                if (args[i].startsWith("--resource")) {
                    resources.add(new Resource(args[++i], args[++i], 
                            Integer.parseInt(args[++i]), 
                            Integer.parseInt(args[++i]), 
                            Integer.parseInt(args[++i])));

                } else if (args[i].startsWith("--script")) {
                    script = args[++i];

                } else if (args[i].startsWith("--input")) {
                    inputDir = args[++i];

                } else if (args[i].startsWith("--output")) {
                    outputDir = args[++i];

                } else {
                    System.err.println("Unknown option: " + args[i]);
                    System.exit(1);
                }
            }

            if (resources.size() == 0 || script == null || 
                    inputDir == null || outputDir == null) {               
                System.out.println("masterkey.bagoftasks.Main " +
                		"[--resource URI javapath maxjobs timelimit bagsize]+" +
                		" --script script --input inputdir --output outputdir");
                System.exit(1);
            }

            FileUtils.ensureFileExists(script); 
            FileUtils.ensureDirExists(inputDir); 
            FileUtils.ensureDirExists(outputDir); 
            
            new Main(resources, script, inputDir, outputDir).run();
        } catch (Exception e) {
            System.err.println("Failed to run bag-of-tasks: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}
