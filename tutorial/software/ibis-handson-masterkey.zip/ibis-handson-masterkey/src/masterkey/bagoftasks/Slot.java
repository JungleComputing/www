package masterkey.bagoftasks;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;

import masterkey.util.FileUtils;

import org.gridlab.gat.GAT;
import org.gridlab.gat.GATObjectCreationException;
import org.gridlab.gat.resources.JavaSoftwareDescription;
import org.gridlab.gat.resources.Job;
import org.gridlab.gat.resources.JobDescription;
import org.gridlab.gat.resources.ResourceBroker;
import org.gridlab.gat.resources.Job.JobState;


/**
 * This class represents an execution slot on some resource.
 * 
 * @author jason
 */
class Slot {
    
    /** The Resource for this execution slot */ 
    public final Resource resource;
    
    // The resource broker to contact this resource.
    private final ResourceBroker broker; 
    
    // The directory containing the input data (local).
    private final String inputDir;
    
    // The directory containing the output data (local).
    private final String outputDir;
    
    // The script to run.
    private final String script;
    
    // The JavaGAT job (if a task is running)
    private Job job;
    
    // The bag of tasks to run.
    private LinkedList<Task> bag;
    
    // A unique ID for the JavaGAT job.
    private int jobID; 
    
    // The name of a generated file containing a string representation 
    // of the bag of tasks.
    private String tasksInFile;
    
    // The name of a generated file containing a string representation 
    // of the tasks that have been executed.
    private String tasksOutFile;
    
    /** 
     * Constructor of an execution slot.
     * 
     * @param resource the resource this execution slot represents.
     * @param broker the ResourceBroker needed to access this resource.
     * @param script the script to run.
     * @param inputDir the local input directory.
     * @param outputDir the local output directory.
     */
    public Slot(Resource resource, ResourceBroker broker, String script, String inputDir, String outputDir) {
        this.resource = resource;
        this.broker = broker;         
        this.script = script;
        this.inputDir = inputDir;
        this.outputDir = outputDir;
    }
    
    /** 
     * Configure an execution slot to run a bag-of-tasks.
     * 
     * @param jobID a unique job ID.
     * @param bag the bag-of-tasks to run.
     * @throws IOException if the configuration failed.
     */
    public void configure(int jobID, LinkedList<Task> bag) throws IOException { 
        this.jobID = jobID;
        this.bag = bag;
        
        // Generate name for the file that will contain the bag-of-tasks.
        tasksInFile = "tasks.in." + jobID;
        
        // Generate name for the file that will contain the tasks that 
        // have been executed.
        tasksOutFile = "tasks.out." + jobID;
      
        // Generate the task.in file
        generateTaskFile();
    }

    /** Clear the execution slot */
    public void clear() { 
        bag = null;
        job = null;
    }
     
    /** 
     * Submit the bag-of-task to the resource.
     * 
     * @throws Exception if the submission has failed.
     */
    public void submit() throws Exception {
        System.out.println("Submitting bag " + jobID + " of size " + bag.size() + " to " + resource.brokerURI);        
        job = broker.submitJob(prepareJob());
    }
    
    /**
     * Check if the bag-of-tasks is done.
     * 
     * @return if the bag-of-tasks is done.
     */
    public boolean isDone() {
        return (job == null || job.getState() == JobState.STOPPED || job.getState() == JobState.SUBMISSION_ERROR);
    }      
    
    // Read the task.out file to see which task of the bag have actually been executed. 
    private void readFinishedTasks(File result, HashSet<Long> done) { 

        BufferedReader reader = null;
        
        try { 
            reader = new BufferedReader(new FileReader(result));
            
            String line = reader.readLine();
            
            while (line != null) { 
                
                String [] tmp = line.split(",");
                
                if (tmp != null && tmp.length == 3) { 
                    done.add(Long.parseLong(tmp[0]));
                    System.out.println("Task " + tmp[0] + " terminated with exit value " + tmp[1] + " (" + tmp[2] + ")");
                } else { 
                    System.out.println("Failed to parse task output: " + line);
                }
                
                line = reader.readLine();
            }            
        } catch (Exception e) {
            System.out.println("Failed to (fully) read result file " + result.getName());
            e.printStackTrace();
        } finally { 
            FileUtils.close(reader);            
        }        
    }
    
    /** 
     * Split the bag-of-tasks into two lists, one containing the finished tasks, and one 
     * containing the skipped tasks. 
     * 
     * @param done a list for the finished tasks.
     * @param skipped a list for the skipped tasks.
     */
    public void retrieveTasks(LinkedList<Task> done, LinkedList<Task> skipped) { 
        
        System.out.println("Processing output of bag " + jobID);
                
        File result = new File(tasksOutFile);
        
        HashSet<Long> doneIDs = new HashSet<Long>();
        
        if (result.exists() && result.isFile() && result.canRead()) { 
            readFinishedTasks(result, doneIDs);
        }
        
        for (Task t : bag) { 
            if (doneIDs.contains(t.ID)) {
                done.add(t);
            } else { 
                skipped.add(t);
            }
        }

        clear();
    }
    
    // Generate the task.in file by writing each of the tasks in the bag (as a string). 
    private void generateTaskFile() throws IOException { 
        
        BufferedWriter writer = new BufferedWriter(new FileWriter(tasksInFile));
        
        for (Task t : bag) { 
            writer.write(Task.write(t) + "\n");
        } 
        
        writer.close();
    }
    
    
    /**
     * Creates a JobDescription for running the bag of tasks on the resource this slot represents. 

     * @return a JobDescription for starting a Job on the resource 
     * @throws GATObjectCreationException if creating the JobDescription failed.  
     */
    private JobDescription prepareJob() throws GATObjectCreationException {

        JavaSoftwareDescription sd = new JavaSoftwareDescription();

        // TODO: set the timelimit on the job ? 
        
        // Set the executable (java), the classpath (jars), the main class, 
        // and the command line arguments   
        sd.setExecutable(resource.javaLocation);
        sd.setJavaClassPath("ipl/*:masterkey-examples.jar:.");
        sd.setJavaMain("masterkey.bagoftasks.BagOfTasksRunner");
        sd.setJavaArguments(tasksInFile, "" + resource.timeLimit, tasksOutFile);
        
        // Create files for stdout and stderr
        sd.setStdout(GAT.createFile("stdout-" + jobID + ".txt"));
        sd.setStderr(GAT.createFile("stderr-" + jobID + ".txt"));

        // Prestage the libraries and property files, plus all input files.
        sd.addPreStagedFile(GAT.createFile("lib/masterkey-examples.jar"));
        sd.addPreStagedFile(GAT.createFile("log4j.properties"));

        sd.addPreStagedFile(GAT.createFile(script));
        sd.addPreStagedFile(GAT.createFile(tasksInFile));

        // Poststage the output task list.
        sd.addPostStagedFile(GAT.createFile(tasksOutFile));

        for (Task task : bag) { 
            sd.addPreStagedFile(GAT.createFile(inputDir + File.separator + task.inputFile));
            sd.addPostStagedFile(GAT.createFile(task.outputFile), GAT.createFile(outputDir + File.separator + task.outputFile)); 
        }     

        return new JobDescription(sd);
    }    
}